# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
# pylint: disable=line-too-long

from knack.arguments import CLIArgumentType


def load_arguments(self, _):

    from azure.cli.core.commands.parameters import tags_type
    from azure.cli.core.commands.validators import get_default_location_from_resource_group
    import azext_customlocation._validators as _validators

    customlocations_name_type = CLIArgumentType(options_list=['--name', '-n'], help='Name of the Customlocation.', id_part=None)

    with self.argument_context('customlocation') as c:
        c.argument('cl_name', customlocations_name_type)
        c.argument('namespace', customlocations_name_type, help='Namespace for Custom Location. Should match namespace where cluster extension operator was created in.', options_list=["--namespace", "-ns"])
        c.argument('location', validator=get_default_location_from_resource_group)
        c.argument('host_resource_id', options_list=['--host-resource-id', '-hr'], help = 'Host resource ID of the connected cluster.')
        c.argument('cluster_extension_ids', nargs='*', options_list=['--cluster-extension-ids', '-c'], help = 'Space-seperated list of the cluster extension ids - input full id in the format /subscription/.../resourceGroups/.../Microsoft.Kubernetes/connectedClusters/.../providers/Microsoft.KubernetesConfiguration/extensions/...' )


    with self.argument_context('customlocation create') as c:
        c.argument('kubeconfig', options_list=['--kubeconfig', '-k'], help = 'Admin Kubeconfig of Cluster. Needs to passed in as a file if the cluster is a non-AAD enabled Cluster.')

    with self.argument_context('customlocation patch') as c:
        c.argument('display_name', options_list=['--display-name', '-dn'], help = 'Display Name of Custom Location.')
        c.argument('tags', options_list=['--tags', '-t'], help = 'A json file for tags for Custom Location.')
