Microsoft Azure CLI 'customlocation' Extension
==========================================

This package is for the 'customlocation' extension.
i.e. 'az customlocation'

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

