# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

import os
import base64
import json
from enum import Enum
from knack.util import CLIError
from azure.cli.core.commands.client_factory import get_mgmt_service_client
from azext_customlocation.vendored_sdks.azure.mgmt.extendedlocation import v2020_07_15_privatepreview as v2020_07_15
import azext_customlocation.helper as helper

# Resource Creation
from azure.cli.core.util import sdk_no_wait
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.cli.core.profiles import ResourceType
from azext_customlocation.vendored_sdks.azure.mgmt.extendedlocation import v2020_07_15_privatepreview as v2020_07_15

def create_customlocation(cmd, resource_group_name, cl_name, cluster_extension_ids, namespace, host_resource_id, kubeconfig=None, location=None, no_wait=False):
    # Validate that subscription is registered for Custom Locations
    try:
        helper.validate_cli_resource_type(
            cmd.cli_ctx, ResourceType.MGMT_RESOURCE_RESOURCES)
    except CLIError as e:
        print(e)
        return

    # Get CustomLocations Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)

    # Check if the Kubeconfig is passed in
    # Object to pass in authentication
    cl_auth = v2020_07_15.models.CustomLocationPropertiesAuthentication()
    if kubeconfig is None:
        cl_auth = None
    else:
        # open the file
        try:
            with open(kubeconfig, 'r') as stream:
                # Parse config file into necessary components.
                kubeconfig_value = stream.read()
                message_bytes = kubeconfig_value.encode('ascii')
                base64_bytes = base64.b64encode(message_bytes)
                base64_kubeconfig = base64_bytes.decode('ascii')
                cl_auth.value = base64_kubeconfig
        except FileNotFoundError as e:
            print("File Not Found", e)
        except Exception as e:
            print("Something went wrong. Try again.", e)

    cl_host_type = v2020_07_15.models.HostType("Kubernetes")

    # parameters
    customlocation = v2020_07_15.models.CustomLocation(
        host_type=cl_host_type.kubernetes,
        location=location,
        display_name=cl_name,
        namespace=namespace,
        cluster_extension_ids=cluster_extension_ids,
        host_resource_id=host_resource_id,
        authentication=cl_auth
    )
    return sdk_no_wait(no_wait, cl_client.create_or_update, resource_group_name=resource_group_name, resource_name=cl_name, parameters=customlocation)


def patch_customlocation(cmd, resource_group_name, cl_name, cluster_extension_ids, namespace, host_resource_id, display_name=None, tags=None, location=None, no_wait=False):
    # Validate that subscription is registered for Custom Locations
    try:
        helper.validate_cli_resource_type(
            cmd.cli_ctx, ResourceType.MGMT_RESOURCE_RESOURCES)
    except CLIError as e:
        print(e)
        return

    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)

    # Check if the Tags is passed in
    if tags is not None:
        # open the file
        try:
            with open(tags, 'r') as tags_file:
                # Read json into python dict
                tags_value = json.load(tags_file)
                tags = tags_value
        except FileNotFoundError as e:
            print("File Not Found", e)
        except Exception as e:
            print("Something went wrong. Try again.", e)

    # Variables are wrapped in PatchableCustomLocations model in update() operation
    return sdk_no_wait(no_wait, cl_client.update, resource_group_name=resource_group_name, resource_name=cl_name,
                       location=location,
                       namespace=namespace,
                       display_name=display_name,
                       cluster_extension_ids=cluster_extension_ids,
                       host_resource_id=host_resource_id,
                       tags=tags)


def update_customlocation(cmd, resource_group_name, cl_name, cluster_extension_ids, namespace, host_resource_id, location=None, no_wait=False):
    # Validate that subscription is registered for Custom Locations
    try:
        helper.validate_cli_resource_type(
            cmd.cli_ctx, ResourceType.MGMT_RESOURCE_RESOURCES)
    except CLIError as e:
        print(e)
        return

    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)

    # parameters
    customlocation = v2020_07_15.models.CustomLocation(
        location=location,
        namespace=namespace,
        display_name=cl_name,
        cluster_extension_ids=cluster_extension_ids,
        host_resource_id=host_resource_id
    )
    return sdk_no_wait(no_wait, cl_client.create_or_update, resource_group_name=resource_group_name, resource_name=cl_name, parameters=customlocation)


def get_customlocation(cmd, resource_group_name, cl_name):
    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)
    return cl_client.get(resource_group_name=resource_group_name, resource_name=cl_name)


def list_customlocations(cmd, resource_group_name=None):
    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)

    if resource_group_name is None:
        return cl_client.list_by_subscription()
    else:
        return cl_client.list_by_resource_group(resource_group_name=resource_group_name)


def enable_resource_types_customlocation(cmd, resource_group_name, cl_name):
    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)
    return cl_client.get_enabled_resource_types(resource_group_name=resource_group_name, resource_name=cl_name)


def delete_customlocation(cmd, resource_group_name, cl_name, no_wait=False):
    # Validate that subscription is registered for Custom Locations
    try:
        helper.validate_cli_resource_type(
            cmd.cli_ctx, ResourceType.MGMT_RESOURCE_RESOURCES)
    except CLIError as e:
        print(e)
        return

    # Get CustomLocation Client
    cl_client = get_mgmt_service_client(
        cmd.cli_ctx, v2020_07_15.CustomLocations)
    return sdk_no_wait(no_wait, cl_client.delete, resource_group_name=resource_group_name, resource_name=cl_name)
