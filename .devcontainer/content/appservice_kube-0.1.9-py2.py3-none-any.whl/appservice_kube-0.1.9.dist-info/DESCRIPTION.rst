Microsoft Azure CLI 'appservice-kube' Extension


