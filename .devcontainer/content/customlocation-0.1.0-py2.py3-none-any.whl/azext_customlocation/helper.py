from knack.util import CLIError
from azure.cli.core.commands.client_factory import get_mgmt_service_client

# function to Validate that subscription is registered for Custom Locations 
def validate_cli_resource_type(cli_ctx, resources):
    resource_client = get_mgmt_service_client(cli_ctx, resources)
    provider = resource_client.providers.get('Microsoft.ExtendedLocation')
    if provider.registration_state != 'Registered':
        raise CLIError('Microsoft.ExtendedLocation provider is not registered.  Run `az provider '+'register -n Microsoft.ExtendedLocation --wait`.')