# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: disable=line-too-long
from azure.cli.core.commands import CliCommandType
from azext_customlocation._client_factory import cf_customlocations


def load_command_table(self, _):

    with self.command_group('customlocation') as g:
        g.custom_command('create', 'create_customlocation')
        g.custom_command('show', 'get_customlocation')
        g.custom_command('delete', 'delete_customlocation')
        g.custom_command('list', 'list_customlocations')
        g.custom_command('enabled-resource-types', 'enable_resource_types_customlocation')
        g.custom_command('update', 'update_customlocation')
        g.custom_command('patch', 'patch_customlocation')

    with self.command_group('customlocation', is_preview=True):
        pass
